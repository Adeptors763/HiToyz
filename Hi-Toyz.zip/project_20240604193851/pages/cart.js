function displayCartItems() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const cartItemsContainer = document.getElementById('cart-items');
    cartItemsContainer.innerHTML = '';

    cartItems.forEach((item, index) => {
        const row = document.createElement('tr');
        const productName = document.createElement('td');
        productName.textContent = item.name;
        row.appendChild(productName);
        const price = document.createElement('td');
        price.textContent = 'Rp. ' + item.price.toFixed(2);
        row.appendChild(price);
        const quantity = document.createElement('td');
        quantity.textContent = '1'; // Assuming quantity is always 1 for now
        row.appendChild(quantity);
        const subtotal = document.createElement('td');
        subtotal.textContent = 'Rp. ' + item.price.toFixed(2); // Subtotal is same as price for now
        row.appendChild(subtotal);
        const action = document.createElement('td'); // Create new column for action
        const removeButton = document.createElement('button'); // Create remove button
        removeButton.textContent = 'Remove';
        removeButton.addEventListener('click', () => removeCartItem(index)); // Add event listener to remove button
        action.appendChild(removeButton);
        row.appendChild(action);
        cartItemsContainer.appendChild(row);
    });

    // Calculate and display subtotal
    const subtotal = cartItems.reduce((total, item) => total + item.price, 0);
    document.getElementById('subtotal').textContent = 'Rp. ' + subtotal.toFixed(2);
    // For now, total is same as subtotal
    document.getElementById('total').textContent = 'Rp. ' + subtotal.toFixed(2);
}

function removeCartItem(index) {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    cartItems.splice(index, 1); // Remove item from cartItems array
    localStorage.setItem('cartItems', JSON.stringify(cartItems)); // Update cartItems in localStorage
    displayCartItems(); // Re-display cart items
}
